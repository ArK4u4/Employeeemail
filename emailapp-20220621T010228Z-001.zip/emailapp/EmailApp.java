package emailapp;

public class EmailApp {
    public static void main (String[] args) {
        Email em1 = new Email("Arvind","kaushik");
//        em1.setAlternateEmail ("ark4u4@outlook.com");
//        System.out.println (em1.getAlternateEmail ());
        System.out.println (em1.showInfo ());


    }
}
